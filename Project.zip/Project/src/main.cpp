#include <bits/stdc++.h>
#include "../headers/Start.h"

using namespace std;

int main()
{
    start_program();
    return 0;
}
